package br.upf.sistemacerveja.service

import br.upf.sistemacerveja.model.Cerveja
import br.upf.sistemacerveja.repository.CervejaRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class CervejaService @Autowired constructor(private val beerRepository: CervejaRepository) {

    fun getAllCervejas(): List<Cerveja> = cervejaRepository.findAll()

    fun getCervejaById(id: Long): Cerveja? = cervejaRepository.findById(id).orElse(null)

    fun createCerveja(cerveja: Cerveja): Cerveja = cervejaRepository.save(cerveja)

    fun updateBeer(id: Long, updatedCerveja: Cerveja): Cerveja {
        updatedCerveja.id = id
        return CervejaRepository.save(updatedCerveja)
    }

    fun deleteCerveja(id: Long) {
        CervejaRepository.deleteById(id)
    }
}