package br.upf.sistemacerveja.repository


import br.upf.sistemacerveja.model.Cerveja


interface CervejaRepository : JpaRepository<Cerveja, Long>

interface JpaRepository<T, U> {

}



