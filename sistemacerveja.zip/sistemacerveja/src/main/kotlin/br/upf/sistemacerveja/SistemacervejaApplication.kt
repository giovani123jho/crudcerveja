package br.upf.sistemacerveja

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SistemacervejaApplication

fun main(args: Array<String>) {
	runApplication<SistemacervejaApplication>(*args)
}
