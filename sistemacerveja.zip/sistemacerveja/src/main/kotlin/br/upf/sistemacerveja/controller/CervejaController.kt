package br.upf.sistemacerveja.controller

import br.upf.sistemacerveja.model.Cerveja
import br.upf.sistemacerveja.service.CervejaService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/cervejas")
class CervejaController @Autowired constructor(private val cervejaService: CervejaService) {

    @GetMapping("/")
    fun getAllCervejas(): List<Cerveja> = cervejaService.getAllCervejas()

    @GetMapping("/{id}")
    fun getCervejaById(@PathVariable id: Long): Cerveja? = cervejaService.getCervejaById(id)

    @PostMapping("/")
    fun createCerveja(@RequestBody cerveja: Cerveja): Cerveja = cervejaService.createCerveja(cerveja)

    @PutMapping("/{id}")
    fun updateCerveja(@PathVariable id: Long, @RequestBody updatedCerveja: Cerveja): Cerveja =
        cervejaService.updateCerveja(id, updatedCerveja)

    @DeleteMapping("/{id}")
    fun deleteCerveja(@PathVariable id: Long) = cervejaService.deleteCerveja(id)
}

private fun CervejaService.updateCerveja(id: Long, updatedCerveja: Cerveja): Cerveja {

}
