package br.upf.sistemacerveja

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SistemacervejaApplicationTests {

	@Test
	fun contextLoads() {
	}

}
